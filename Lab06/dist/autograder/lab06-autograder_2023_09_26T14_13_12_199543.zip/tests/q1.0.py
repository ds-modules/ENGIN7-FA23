OK_FORMAT = True

test = {   'name': 'q1.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> # Check functions were tested\n'
                                               '>>> assert get_hash(type(q1_u0)) != \'14e736438b115821cbb9b7ac0ba79034\', "Make sure to test your function!"\n'
                                               '>>> assert get_hash(type(q1_u)) != \'14e736438b115821cbb9b7ac0ba79034\', "Make sure to test your function!"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check scalar input\n'
                                               ">>> assert get_hash(np.round(u0(0),decimals= 2))   == '30565a8911a6bb487e3745c0ea3c8224', 'Check your u0 function.'\n"
                                               ">>> assert get_hash(np.round(u0(10),decimals= 2))  == 'bf9cba947baf9cc43f447e0e0fc7efce', 'Check your u0 function.'\n"
                                               ">>> assert get_hash(np.round(u0(60),decimals= 2))  == '9f7c34c89841d32c138e886829eb4154', 'Check your u0 function.'\n"
                                               ">>> assert get_hash(np.round(u0(100),decimals= 2)) == '30565a8911a6bb487e3745c0ea3c8224', 'Check your u0 function.'\n"
                                               '>>> \n'
                                               '>>> # Check array input\n'
                                               '>>> x = np.linspace(0,100)\n'
                                               ">>> assert get_hash(len(u0(x))) == 'c0c7c76d30bd3dcaefc96f40275bdc0a', 'Check your u0 function.'\n"
                                               ">>> assert get_hash(np.round(np.sum(u0(x)),decimals= 2)) == '82fd5432008dcbb742f92940ad26cd05', 'Check your u0 function.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check scalar input\n'
                                               ">>> assert get_hash(np.round(u(0,100),decimals= 2)) == '30565a8911a6bb487e3745c0ea3c8224', 'Check your u function.'\n"
                                               ">>> assert get_hash(np.round(u(10,10),decimals= 2)) == '19ca1e8274ab2a38604c8baa84ef7baa', 'Check your u function.'\n"
                                               ">>> assert get_hash(np.round(u(60,30),decimals= 2)) == '89dbc31f785433f9aeefa440b26f01a7', 'Check your u function.'\n"
                                               ">>> assert get_hash(np.round(u(100,100),decimals= 2)) == '30565a8911a6bb487e3745c0ea3c8224', 'Check your u function.'\n"
                                               '>>> \n'
                                               '>>> # Check array input\n'
                                               '>>> x = np.linspace(0,100)\n'
                                               ">>> assert get_hash(len(u(x,10))) == 'c0c7c76d30bd3dcaefc96f40275bdc0a', 'Check your u function.'\n"
                                               ">>> assert get_hash(np.round(np.sum(u(x,10)),decimals= 2)) =='dd665bc9865f92f5c247d793c1f5c019' , 'Check your u function.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
