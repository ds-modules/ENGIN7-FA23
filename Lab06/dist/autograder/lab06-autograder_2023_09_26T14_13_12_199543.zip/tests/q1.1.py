OK_FORMAT = True

test = {   'name': 'q1.1',
    'points': 4,
    'suites': [   {   'cases': [   {'code': ">>> get_hash(np.round(np.sum(x_q1),decimals= 2))\n'3b68e4b87a954d6116e95334c6c59068'", 'hidden': False, 'locked': False},
                                   {'code': ">>> fig_1.axes[0].get_xlabel().upper()\n'X, CM'", 'hidden': False, 'locked': False},
                                   {'code': ">>> get_hash('-')\n'336d5ebc5436534e61d16e63ddfca327'", 'hidden': False, 'locked': False},
                                   {   'code': '>>> # Check x grid\n'
                                               ">>> assert get_hash(len(x_q1)) == 'a9b7ba70783b617e9998dc4dd82eb3c5', 'Check the x grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(x_q1),decimals= 2)) == '3b68e4b87a954d6116e95334c6c59068', 'Check the x grid.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check linestyles\n'
                                               ">>> assert fig_1.axes[0].get_lines()[0].get_linestyle() == '-', 'Check the line styles.'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[1].get_linestyle() == '--', 'Check the line styles.'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[2].get_linestyle() == '-.', 'Check the line styles.'\n"
                                               '>>> \n'
                                               '>>> # Check line colors\n'
                                               ">>> assert fig_1.axes[0].get_lines()[0].get_color() == 'b', 'Check the line colors.'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[1].get_color() == 'r', 'Check the line colors.'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[2].get_color() == 'g', 'Check the line colors.'\n"
                                               '>>> \n'
                                               '>>> # Check line labels\n'
                                               ">>> assert fig_1.axes[0].get_lines()[0].get_label() == 't = 0s', 'Check the line labels.'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[1].get_label() == 't = 50s', 'Check the line labels.'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[2].get_label() == 't = 150s', 'Check the line labels.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check xlabel and fontsize\n'
                                               ">>> assert 'X' in fig_1.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert 'CM' in fig_1.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert fig_1.axes[0].xaxis.label.get_fontsize() == 14, 'Check the x-axis label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check ylabel and fontsize\n'
                                               ">>> assert 'TEMPERATURE' in fig_1.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert 'DEGREES' in fig_1.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert 'CELSIUS' in fig_1.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert fig_1.axes[0].get_ylabel() == 'Temperature, degrees Celsius', 'Check the y-axis label.'\n"
                                               ">>> assert fig_1.axes[0].yaxis.label.get_fontsize() == 14, 'Check the y-axis label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check title and fontsize\n'
                                               ">>> assert 'TEMPERATURE' in fig_1.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'DISTRIBUTION' in fig_1.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'COPPER' in fig_1.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'BAR' in fig_1.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert fig_1.axes[0].title.get_fontsize() == 16, 'Check the title label fontsize.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check legend is added\n'
                                               ">>> assert type(fig_1.axes[0].get_legend()) != type(None), 'Make sure to add a legend.'\n"
                                               '>>> \n'
                                               '>>> # Check xlim and ylim\n'
                                               ">>> assert fig_1.axes[0].get_xlim() == (0.0, 100.0), 'Check the x-axis limits.'\n"
                                               ">>> assert fig_1.axes[0].get_ylim() == (-120.0, 120.0), 'Check the y-axis limits.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
