OK_FORMAT = True

test = {   'name': 'q2.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> # Check function was tested\n>>> assert get_hash(type(q2)) != \'14e736438b115821cbb9b7ac0ba79034\', "Make sure to test your function!"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check scalar input\n'
                                               ">>> assert get_hash(np.round(mode_shape(0.2,0.6,1,1,1,1),decimals= 2)) == '2363c78ab7dba59b8443d958b47cfa2b', 'Check your mode_shape function.'\n"
                                               ">>> assert get_hash(np.round(mode_shape(0.23,0.7,1,1,3,4),decimals= 2)) == 'ab01272978f4106a12ede6fe2a850be4', 'Check your mode_shape function.'\n"
                                               ">>> assert get_hash(np.round(mode_shape(0.3,0.3,1,1,8,1),decimals= 2)) == '671a647819140975b0649cb3d2f4804a', 'Check your mode_shape function.'\n"
                                               ">>> assert get_hash(np.round(mode_shape(0.7,0.8,1,1,5,5),decimals= 2)) == '30565a8911a6bb487e3745c0ea3c8224', 'Check your mode_shape function.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check array input\n'
                                               '>>> x = np.linspace(0,100)\n'
                                               ">>> assert get_hash(len(mode_shape(x,x,1,1,1,1))) == 'c0c7c76d30bd3dcaefc96f40275bdc0a', 'Make sure your mode_shape function works for x and y "
                                               "arrays.'\n"
                                               ">>> assert get_hash(np.round(np.sum(mode_shape(x,x,1,1,1,1)),decimals= 2)) == '42b4dad1f1f82501da84d8942aa3343b', 'Make sure your mode_shape function "
                                               "works for x and y arrays.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
