OK_FORMAT = True

test = {   'name': 'q2.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> # Check 1D x grid\n'
                                               ">>> assert get_hash(len(x_q2_1)) == 'a9b7ba70783b617e9998dc4dd82eb3c5', 'Check your 1D x grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(x_q2_1),decimals= 2)) == '1c51ac3926a046148a24ba048afc85cd', 'Check your 1D x grid.'\n"
                                               '>>> \n'
                                               '>>> # Check 1D y grid\n'
                                               ">>> assert get_hash(len(y_q2_1)) == 'a9b7ba70783b617e9998dc4dd82eb3c5', 'Check your 1D y grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(y_q2_1),decimals= 2)) == '1434f81012ce9c2aba692d5177889ef4', 'Check your 1D y grid.'\n"
                                               '>>> \n'
                                               '>>> # Check 1D x grid\n'
                                               ">>> assert get_hash(X_q2_1.shape) == '2c279ef3676bba689eabb103f0a319e8', 'Check your 2D x grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(X_q2_1),decimals= 2)) == 'ead4a206965a49fc387fd5b4de90867c', 'Check your 2D x grid.'\n"
                                               '>>> \n'
                                               '>>> # Check 1D y grid\n'
                                               ">>> assert get_hash(Y_q2_1.shape) == '2c279ef3676bba689eabb103f0a319e8', 'Check your 2D y grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(Y_q2_1),decimals= 2)) == 'be6a5089b8e4ba482c427df57552ad5f', 'Check your 2D y grid.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check colormap\n'
                                               ">>> assert fig_2.axes[0].get_children()[0].get_cmap().name == 'plasma', 'Check colormap.'\n"
                                               '>>> \n'
                                               '>>> # Check aspect ratio \n'
                                               ">>> assert fig_2.axes[0].get_aspect() == 'equal', 'Check the axes aspect ratio.'\n"
                                               '>>> \n'
                                               '>>> # Check xlabel and fontsize\n'
                                               ">>> assert 'X' in fig_2.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert fig_2.axes[0].xaxis.label.get_fontsize() == 12, 'Check the x-axis label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check ylabel and fontsize\n'
                                               ">>> assert'Y' in fig_2.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert fig_2.axes[0].yaxis.label.get_fontsize() == 12, 'Check the y-axis label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check zlabel and fontsize\n'
                                               ">>> assert 'Z' in fig_2.axes[0].get_zlabel().upper(), 'Check the z-axis label.'\n"
                                               ">>> assert fig_2.axes[0].zaxis.label.get_fontsize() == 12, 'Check the y-axis label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check title and fontsize\n'
                                               ">>> assert 'NATURAL' in fig_2.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'MODE' in fig_2.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'SHAPE' in fig_2.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'M' in fig_2.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert '3' in fig_2.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'N' in fig_2.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert '2' in fig_2.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert fig_2.axes[0].title.get_fontsize() == 14, 'Check the title label fontsize.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
