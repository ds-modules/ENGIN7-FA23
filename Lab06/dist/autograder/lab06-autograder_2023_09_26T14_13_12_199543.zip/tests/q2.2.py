OK_FORMAT = True

test = {   'name': 'q2.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> # Check 1D x grid\n'
                                               ">>> assert get_hash(len(x_q2_2)) == 'a9b7ba70783b617e9998dc4dd82eb3c5', 'Check your 1D x grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(x_q2_2),decimals= 2)) == '02541b7cbb840b5f6bd8eff3c9f56f61', 'Check your 1D x grid.'\n"
                                               '>>> \n'
                                               '>>> # Check 1D y grid\n'
                                               ">>> assert get_hash(len(y_q2_2)) == 'a9b7ba70783b617e9998dc4dd82eb3c5', 'Check your 1D y grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(y_q2_2),decimals= 2)) == '02541b7cbb840b5f6bd8eff3c9f56f61', 'Check your 1D y grid.'\n"
                                               '>>> \n'
                                               '>>> # Check 1D x grid\n'
                                               ">>> assert get_hash(X_q2_2.shape) == '2c279ef3676bba689eabb103f0a319e8', 'Check your 2D x grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(X_q2_2),decimals= 2)) == '21819d66f20373895e5f413cfe0e5c0f', 'Check your 2D x grid.'\n"
                                               '>>> \n'
                                               '>>> # Check 1D y grid\n'
                                               ">>> assert get_hash(len(Y_q2_2)) == 'a9b7ba70783b617e9998dc4dd82eb3c5', 'Check your 2D y grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(Y_q2_2),decimals= 2)) == '21819d66f20373895e5f413cfe0e5c0f', 'Check your 2D y grid.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check title\n'
                                               ">>> assert fig_3._suptitle.get_text() == 'Mode shapes', 'Check figure suptitle.'\n"
                                               ">>> assert fig_3._suptitle.get_fontsize() == 16, 'Check figure suptitle font size.'\n"
                                               '>>> # Check subplots\n'
                                               '>>> assert axs.shape == (2, 2), \'Make sure you have a 2x2 subplot layout stored in the variable "axs".\'\n'
                                               '>>> lst = [1,2]\n'
                                               '>>> for m in lst:\n'
                                               '...     for n in lst: \n'
                                               "...         assert axs[m-1,n-1].get_xlabel().upper() == 'X', 'Check x-axis labels.'\n"
                                               "...         assert axs[m-1,n-1].get_ylabel().upper() == 'Y', 'Check y-axis labels.'\n"
                                               "...         assert axs[m-1,n-1].get_zlabel().upper() == 'Z', 'Check z-axis labels.'\n"
                                               "...         assert axs[m-1,n-1].get_title() == 'm = {m}, n = {n}'.format(m=m,n=n), 'Check title labels.'\n"
                                               "...         assert axs[m-1,n-1].get_children()[0].get_cmap().name == 'coolwarm', 'Check colormap.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
