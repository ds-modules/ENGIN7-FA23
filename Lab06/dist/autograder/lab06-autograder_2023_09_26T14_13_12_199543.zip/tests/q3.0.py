OK_FORMAT = True

test = {   'name': 'q3.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> # Check grids \n'
                                               ">>> assert get_hash(np.round(np.sum(theta),decimals= 2)) == '9311ad9f26394d518925abac95b99be8', 'Check theta 1D grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(rr),decimals= 2)) == '381a7a26ff2526446cbb97fee6f8505a', 'Check r 1D grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(t),decimals= 2)) == 'b9d0eb1983a1cf8354d55656a60c03fb', 'Check r 2D grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(r),decimals= 2)) == '35ce9af3f1187f980f3b1bebcd574a7b', 'Check theta 2D grid.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check grids \n'
                                               ">>> assert get_hash(np.round(np.sum(pressure),decimals= 2)) == '81ba63f8e5af6c7eb551de20fc6f7088', 'Check pressure 2D grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(stream),decimals= 2)) == '30565a8911a6bb487e3745c0ea3c8224', 'Check stream 2D grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(velocity_potential),decimals= 2)) == '55aa3a294d30e95cb206ecfc1b85dee1', 'Check velocity_potential 2D grid.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
