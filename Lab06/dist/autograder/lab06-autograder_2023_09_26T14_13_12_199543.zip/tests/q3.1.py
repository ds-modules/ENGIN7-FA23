OK_FORMAT = True

test = {   'name': 'q3.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> # Check 1D x grid\n'
                                               ">>> assert get_hash(X_q3_1.shape) == '2c279ef3676bba689eabb103f0a319e8', 'Check your 2D x grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(X_q3_1),decimals= 2)) == '381a7a26ff2526446cbb97fee6f8505a', 'Check your 2D x grid.'\n"
                                               '>>> \n'
                                               '>>> # Check 1D y grid\n'
                                               ">>> assert get_hash(Y_q3_1.shape) == '2c279ef3676bba689eabb103f0a319e8', 'Check your 2D y grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(Y_q3_1),decimals= 2)) == '30565a8911a6bb487e3745c0ea3c8224', 'Check your 2D y grid.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check colorbar\n'
                                               ">>> assert len(cbar_ticks_q3_1) == 2, 'Check colorbar ticks.'\n"
                                               ">>> assert np.isclose(cbar_ticks_q3_1[0],-150,rtol=1e-2) , 'Check colorbar ticks.'\n"
                                               ">>> assert np.isclose(cbar_ticks_q3_1[1],50,rtol=1e-2) , 'Check colorbar ticks.'\n"
                                               ">>> assert cbar_ax_q3_1.get_yticklabels()[0].get_text().upper() == 'LOW', 'Check colorbar ticks.'\n"
                                               ">>> assert cbar_ax_q3_1.get_yticklabels()[1].get_text().upper() == 'HIGH', 'Check colorbar ticks.'\n"
                                               '>>> \n'
                                               '>>> # Check pressure plot\n'
                                               ">>> assert pressure_contour.get_cmap().name == 'jet', 'Check pressure_contour colormap.'\n"
                                               ">>> assert 45 < len(pressure_contour.levels) < 55, 'Check pressure_contour levels.'\n"
                                               '>>> \n'
                                               '>>> # Check stream plot\n'
                                               ">>> assert stream_contour.linewidths == 0.8, 'Check stream_contour line width.'\n"
                                               ">>> assert 45 < len(stream_contour.levels) < 55, 'Check stream_contour levels.'\n"
                                               ">>> assert stream_contour.tcolors[0][0] == (0,0,0,1), 'Check stream_contour line colors.'\n"
                                               '>>> \n'
                                               '>>> # Check velocity plot\n'
                                               ">>> assert velocity_contour.linewidths == 0.8, 'Check velocity_contour line width.'\n"
                                               ">>> assert 45 < len(velocity_contour.levels) < 55, 'Check velocity contour levels.'\n"
                                               ">>> assert velocity_contour.tcolors[0][0] == (1,1,1,1), 'Check stream_contour line colors.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check xlabel and fontsize\n'
                                               ">>> assert 'X' in fig_4.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert fig_4.axes[0].xaxis.label.get_fontsize() == 12, 'Check the x-axis label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check ylabel and fontsize\n'
                                               ">>> assert 'Y' in fig_4.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert fig_4.axes[0].yaxis.label.get_fontsize() == 12, 'Check the y-axis label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check title and fontsize\n'
                                               ">>> assert 'PRESSURE' in fig_4.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'FIELD' in fig_4.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert fig_4.axes[0].title.get_fontsize() == 14, 'Check the title label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check xlim and ylim\n'
                                               ">>> assert fig_4.axes[0].get_xlim() == (-5, 5), 'Check the x-axis limits.'\n"
                                               ">>> assert fig_4.axes[0].get_ylim() == (-5, 5), 'Check the y-axis limits.'\n"
                                               '>>> \n'
                                               '>>> # Check xticks and yticks\n'
                                               ">>> assert len(fig_4.axes[0].get_xticks()) == 0, 'Check the x-axis ticks.'\n"
                                               ">>> assert len(fig_4.axes[0].get_yticks()) == 0, 'Check the y-axis ticks.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
