OK_FORMAT = True

test = {   'name': 'q3.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> # Check vr\n'
                                               ">>> assert get_hash(vr.shape) == '2c279ef3676bba689eabb103f0a319e8', 'Check your 2D vr grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(vr),decimals= 2)) == '75cd8970acd3ddaa0d10134c11c32ce7', 'Check your 2D vr grid.'\n"
                                               '>>> \n'
                                               '>>> # Check vt\n'
                                               ">>> assert get_hash(vt.shape) == '2c279ef3676bba689eabb103f0a319e8', 'Check your 2D vt grid.'\n"
                                               ">>> assert get_hash(np.round(np.sum(vt),decimals= 2)) == 'e80c77464a0cfaf2c46a5574f6bc76b9', 'Check your 2D vt grid.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check quiver plot\n'
                                               ">>> assert v_quiver.scale == 200, 'Checl quiver plot scale.'\n"
                                               ">>> assert len(v_quiver.X) == 1600, 'Make sure to plot at every 25th grid point only.'\n"
                                               ">>> assert get_hash(np.round(np.sum(v_quiver.X),decimals= 2)) == '5ab881cdc85e2fc2abe9a30734de1b5b', 'Make sure to plot at every 25th grid point "
                                               "only.'\n"
                                               ">>> assert len(v_quiver.Y) == 1600, 'Make sure to plot at every 25th grid point only.'\n"
                                               ">>> assert get_hash(np.round(np.sum(v_quiver.Y),decimals= 2)) == 'bb42d52e328cb7ecb4a0732d34fd1a71', 'Make sure to plot at every 25th grid point "
                                               "only.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check colorbar\n'
                                               ">>> assert len(cbar_ticks_q3_2) == 2, 'Check colorbar ticks.'\n"
                                               ">>> assert np.isclose(cbar_ticks_q3_2[0],0,rtol=1e-2) , 'Check colorbar ticks.'\n"
                                               ">>> assert np.isclose(cbar_ticks_q3_2[1],19.99,rtol=1e-2) , 'Check colorbar ticks.'\n"
                                               ">>> assert cbar_ax_q3_2.get_yticklabels()[0].get_text() == 'Low', 'Check colorbar ticks.'\n"
                                               ">>> assert cbar_ax_q3_2.get_yticklabels()[1].get_text() == 'High', 'Check colorbar ticks.'\n"
                                               '>>> \n'
                                               '>>> # Check pressure plot\n'
                                               ">>> assert v_contour.get_cmap().name == 'jet', 'Check pressure_contour colormap.'\n"
                                               ">>> assert 25 < len(v_contour.levels) < 35, 'Check pressure_contour levels.'\n"
                                               '>>> \n'
                                               '>>> # Check stream plot\n'
                                               ">>> assert stream_contour.linewidths == 0.8, 'Check stream_contour line width.'\n"
                                               ">>> assert 45 < len(stream_contour.levels) < 55, 'Check stream_contour levels.'\n"
                                               ">>> assert stream_contour.tcolors[0][0] == (0,0,0,1), 'Check stream_contour line colors.'\n"
                                               '>>> \n'
                                               '>>> # Check velocity plot\n'
                                               ">>> assert velocity_contour.linewidths == 0.8, 'Check velocity_contour line width.'\n"
                                               ">>> assert 45 < len(velocity_contour.levels) < 55, 'Check velocitycontour levels.'\n"
                                               ">>> assert velocity_contour.tcolors[0][0] == (1,1,1,1), 'Check stream_contour line colors.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check xlabel and fontsize\n'
                                               ">>> assert 'X' in fig_5.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert fig_5.axes[0].xaxis.label.get_fontsize() == 12, 'Check the x-axis label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check ylabel and fontsize\n'
                                               ">>> assert 'Y' in fig_5.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert fig_5.axes[0].yaxis.label.get_fontsize() == 12, 'Check the y-axis label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check title and fontsize\n'
                                               ">>> assert 'VELOCITY' in fig_5.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'FIELD' in fig_5.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert fig_5.axes[0].title.get_fontsize() == 14, 'Check the title label fontsize.'\n"
                                               '>>> \n'
                                               '>>> # Check xlim and ylim\n'
                                               ">>> assert fig_5.axes[0].get_xlim() == (-3, 3), 'Check the x-axis limits.'\n"
                                               ">>> assert fig_5.axes[0].get_ylim() == (-3, 3), 'Check the y-axis limits.'\n"
                                               '>>> \n'
                                               '>>> # Check xticks and yticks\n'
                                               ">>> assert len(fig_5.axes[0].get_xticks()) == 0, 'Check the x-axis ticks.'\n"
                                               ">>> assert len(fig_5.axes[0].get_yticks()) == 0, 'Check the y-axis ticks.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
