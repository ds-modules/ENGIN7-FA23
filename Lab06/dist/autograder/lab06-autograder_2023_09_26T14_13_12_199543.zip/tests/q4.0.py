OK_FORMAT = True

test = {   'name': 'q4.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> # Check read data type\n'
                                               ">>> assert isinstance(wind_x, np.ndarray), 'Make sure to convert the wind_x data to a numpy array.'\n"
                                               ">>> assert isinstance(wind_y, np.ndarray), 'Make sure to convert the wind_y data to a numpy array.'\n"
                                               ">>> assert isinstance(wind_u, np.ndarray), 'Make sure to convert the wind_u data to a numpy array.'\n"
                                               ">>> assert isinstance(wind_v, np.ndarray), 'Make sure to convert the wind_v data to a numpy array.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check data correctness\n'
                                               ">>> assert get_hash(np.round(np.sum(wind_x),decimals= 2)) == 'f3e88106d7648572e91240d8ddfd7f65', 'Make sure the wind_x is stored in X.'\n"
                                               ">>> assert get_hash(np.round(np.sum(wind_y),decimals= 2)) == 'cf87726119a3db49884cc2e364dbe32a', 'Make sure the wind_y is stored in Y.'\n"
                                               ">>> assert get_hash(np.round(np.sum(wind_u),decimals= 2)) == '02e71c8357f8983537872ad2f30580e4', 'Make sure the wind_u is stored in U.'\n"
                                               ">>> assert get_hash(np.round(np.sum(wind_v),decimals= 2)) == 'dda186858e2cec344497f604ebb95dab', 'Make sure the wind_v is stored in V.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
