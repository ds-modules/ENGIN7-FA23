OK_FORMAT = True

test = {   'name': 'q4.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> import pandas as pd\n'
                                               ">>> q4_1 = pd.read_csv('resources/wind_mag.csv',header=None).sum().sum()\n"
                                               ">>> assert get_hash(np.round(np.sum(wind_mag),decimals= 2)) == '872e27abbbc3735010e8d1f58ae6c465', 'Check the wind magnitude computation.' \n"
                                               ">>> assert get_hash(np.round(q4_1,decimals= 2)) == '872e27abbbc3735010e8d1f58ae6c465', 'Check the write to csv command.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
