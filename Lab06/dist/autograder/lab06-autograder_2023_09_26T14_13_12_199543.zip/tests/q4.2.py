OK_FORMAT = True

test = {   'name': 'q4.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> # Check velocity plot\n'
                                               ">>> assert wind_contour.get_cmap().name == 'coolwarm', 'Check wind_contour colormap.'\n"
                                               ">>> assert 15 < len(wind_contour.levels) < 25, 'Check velocitycontour levels.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check title\n'
                                               ">>> assert 'WIND' in fig_6.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'VELOCITY' in fig_6.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'MAGNITUDE' in fig_6.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               '>>> \n'
                                               '>>> # Check xlim and ylim\n'
                                               ">>> assert fig_6.axes[0].get_xlim() == (-134.3, -70.188), 'Check the x-axis limits.'\n"
                                               ">>> assert fig_6.axes[0].get_ylim() == (17.5, 60.0), 'Check the y-axis limits.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check grid\n'
                                               ">>> assert grid.top_labels == False, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.bottom_labels == True, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.left_labels == True, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.right_labels == False, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.collection_kwargs['alpha'] == 0.5 , 'Check grid alpha'\n"
                                               ">>> assert grid.collection_kwargs['linestyle'] == ':' , 'Check grid linestyle'\n"
                                               ">>> assert grid.collection_kwargs['color'] == 'k' , 'Check grid color'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
