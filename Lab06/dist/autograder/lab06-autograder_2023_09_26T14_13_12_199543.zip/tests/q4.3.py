OK_FORMAT = True

test = {   'name': 'q4.3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> # Check quiver plot data\n'
                                               ">>> assert np.isclose(np.sum(vel_quiver.X),np.sum(wind_x),rtol = 1e-2), 'Check quiver plot data.'\n"
                                               ">>> assert np.isclose(np.sum(vel_quiver.Y),np.sum(wind_y),rtol = 1e-2), 'Check quiver plot data.'\n"
                                               ">>> assert np.isclose(np.sum(vel_quiver.U),np.sum(wind_u),rtol = 1e-2), 'Check quiver plot data.'\n"
                                               ">>> assert np.isclose(np.sum(vel_quiver.V),np.sum(wind_v),rtol = 1e-2), 'Check quiver plot data.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check title\n'
                                               ">>> assert 'WIND' in fig_7.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'VELOCITY' in fig_7.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'FIELD' in fig_7.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               '>>> \n'
                                               '>>> # Check colorbar \n'
                                               ">>> assert 'MAGNITUDE' in cbar.ax.get_ylabel().upper(), 'Check the colorbar label.'\n"
                                               '>>> \n'
                                               '>>> # Check grid\n'
                                               ">>> assert grid.top_labels == False, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.bottom_labels == True, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.left_labels == True, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.right_labels == False, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.collection_kwargs['alpha'] == 0.5 , 'Check grid alpha'\n"
                                               ">>> assert grid.collection_kwargs['linestyle'] == ':' , 'Check grid linestyle'\n"
                                               ">>> assert grid.collection_kwargs['color'] == 'k' , 'Check grid color'\n"
                                               '>>> \n'
                                               '>>> # Check xlim and ylim\n'
                                               ">>> assert fig_7.axes[0].get_xlim() == (-134.3, -70.188), 'Check the x-axis limits.'\n"
                                               ">>> assert fig_7.axes[0].get_ylim() == (17.5, 60.0), 'Check the y-axis limits.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check the color of vector arrows\n'
                                               '>>> import matplotlib\n'
                                               '>>> assert np.isclose(np.sum(matplotlib.cm.ScalarMappable(norm=vel_quiver.norm, '
                                               "cmap=vel_quiver.cmap).to_rgba(wind_mag).flatten()),np.sum(vel_quiver.get_facecolor().flatten()),rtol = 1e-2), 'Use wind_mag as the colormap values.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
