OK_FORMAT = True

test = {   'name': 'q5.0',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> # Check histogram\n'
                                               ">>> assert get_hash(len(values)) == 'e4da3b7fbbce2345d7772b0674a318d5', 'Check bin count.'\n"
                                               ">>> assert get_hash(len(bins)) == '1679091c5a880faf6fb5e6087eb1b2dc', 'Check bin count.'\n"
                                               ">>> assert get_hash(sum(values)) == '7359bd4fcd36e2be25916898a1e291b0', 'Check histogram data.'\n"
                                               ">>> assert get_hash(sum(bins)) == '12e9099d922d8928c4087e78fffc4975', 'Check bin range.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check xlabel \n'
                                               ">>> assert 'MAGNITUDE' in fig_8.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               '>>> # Check ylabel \n'
                                               ">>> assert 'FREQUENCY' in fig_8.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               '>>> # Check title \n'
                                               ">>> assert 'CONTINENTAL' in fig_8.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'EARTHQUAKES' in fig_8.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert '2022' in fig_8.axes[0].get_title().upper(), 'Check the title label.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
