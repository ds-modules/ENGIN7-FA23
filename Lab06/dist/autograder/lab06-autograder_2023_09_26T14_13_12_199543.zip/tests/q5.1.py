OK_FORMAT = True

test = {   'name': 'q5.1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> # Check plot data\n'
                                               ">>> assert np.isclose(np.sum(eq_scatter.get_offsets()[:,0]),df['longitude'].sum(),rtol = 1e-2), 'Check scatter plot data.'\n"
                                               ">>> assert np.isclose(np.sum(eq_scatter.get_offsets()[:,1]),df['latitude'].sum(),rtol = 1e-2), 'Check scatter plot data.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check marker sizes\n'
                                               ">>> assert np.isclose(np.sum(eq_scatter.get_sizes()),(df['mag']**4).sum(),rtol = 1e-2), 'Check the marker size mapping.'\n"
                                               '>>> # Check marker colors\n'
                                               '>>> import matplotlib\n'
                                               '>>> assert np.isclose(np.sum(matplotlib.cm.ScalarMappable(norm=eq_scatter.norm, '
                                               "cmap=eq_scatter.cmap).to_rgba(df['mag'],alpha=0.5).flatten()),np.sum(eq_scatter.get_facecolor().flatten()),rtol = 1e-2), 'Use the earthquake magnitude "
                                               "as the colormap values. Make sure you set the color alpha as well.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> # Check title'CA area earthquakes in 2022'\n"
                                               ">>> assert 'CA' in fig_9.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'EARTHQUAKES' in fig_9.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert '2022' in fig_9.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               '>>> \n'
                                               '>>> # Check colorbar \n'
                                               ">>> assert 'MAGNITUDE' in cbar.ax.get_ylabel().upper(), 'Check the colorbar label.'\n"
                                               '>>> \n'
                                               '>>> # Check grid\n'
                                               ">>> assert grid.top_labels == False, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.bottom_labels == True, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.left_labels == True, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.right_labels == False, 'Make sure to have labels only on the bottom and left sides.'\n"
                                               ">>> assert grid.collection_kwargs['alpha'] == 0.5 , 'Check grid alpha'\n"
                                               ">>> assert grid.collection_kwargs['linestyle'] == ':' , 'Check grid linestyle'\n"
                                               ">>> assert grid.collection_kwargs['color'] == 'k' , 'Check grid color'\n"
                                               '>>> \n'
                                               '>>> # Check xlim and ylim\n'
                                               ">>> assert np.isclose(np.sum(fig_9.axes[0].get_xlim()),np.sum([-126,-114]), rtol = 1e-2), 'Check the x-axis limits.'\n"
                                               ">>> assert np.isclose(np.sum(fig_9.axes[0].get_ylim()),np.sum([32,42]), rtol = 1e-2), 'Check the y-axis limits.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
